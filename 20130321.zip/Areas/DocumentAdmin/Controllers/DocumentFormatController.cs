﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Entity;
using System.Web;
using System.Web.Mvc;
using QML.Library;
using QML.Library.Utilities;
using QML.Library.Helpers;
using QML.Library.Auth;
using QML.Library.Base.Controllers;
using QML.Library.Attributes;
using QML.Web.UI.Areas.DocumentAdmin.Helpers;
using QML.Web.UI.Areas.DocumentAdmin.Models;
using System.IO;
using System.Web.Helpers;

namespace QML.Web.UI.Areas.DocumentAdmin.Controllers
{
    public class DocumentFormatController : SecuredController
    {
        //
        // GET: /DocumentAdmin/DocumentFormat/
        HanuELibraryEntities db = new HanuELibraryEntities();
        [Menu(Title = "Danh sách", Path = "Định dạng văn bản", Order = 1)]
        public ActionResult Index()
        {
            var format = from f in db.DocumentFormats select f;
            return View(format.ToList());
        }

        //
        // GET: /DocumentAdmin/DocumentFormat/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /DocumentAdmin/DocumentFormat/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /DocumentAdmin/DocumentFormat/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        
        //
        // GET: /DocumentAdmin/DocumentFormat/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /DocumentAdmin/DocumentFormat/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /DocumentAdmin/DocumentFormat/Delete/5
 
        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /DocumentAdmin/DocumentFormat/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
