﻿using System;
using System.Collections.Generic;
using System.Linq;
using QML.Library.Base.Controllers;
using QML.Web.UI.Areas.DocumentAdmin.Models;

namespace QML.Web.UI.Controllers
{
    public class EssentialController : SecuredController
    {
        //
        // GET: /Essential/
        HanuELibraryEntities db = new HanuELibraryEntities();
        public IEnumerable<DocumentEssential> getLatestBooks()
        {
            IEnumerable<DocumentEssential> model = (from df in db.DocumentsFiles
                                                    join doc in db.Documents on df.DocumentID equals doc.DocumentID
                                                    where df.Status == "Hiển thị"
                                                    select new DocumentEssential
                                                    {
                                                        DocumentID = df.DocumentID,
                                                        BookFee = df.BookFee.Value,
                                                        CategoryID = df.CategoryID.Value,
                                                        Description = doc.Description,
                                                        FormatID = df.FormatID.Value,
                                                        IsDeleted = df.IsDeleted.Value,
                                                        Status = df.Status,
                                                        Subject = doc.Subject,
                                                        IsHasInfo = df.IsHasInfo.Value,
                                                        Language = doc.Language,
                                                        Thumbnail = df.Thumbnail,
                                                        Title = doc.Title,
                                                        ViewCount = df.ViewCount.Value,
                                                        Creator = doc.Creator,
                                                        Identifier = doc.Identifier,
                                                        Publisher = doc.Publisher,
                                                        Format = doc.Format,
                                                        FileSource = df.FileSource,
                                                    });
            IEnumerable<DocumentEssential> view_model = null;
            if (IsPremium())
            {
                view_model = model.Where(p => p.IsHasInfo == true && p.IsDeleted == false).OrderByDescending(p => p.DocumentID).Take(30);
            }
            else
                view_model = model.Where(p => p.IsHasInfo == true && p.IsDeleted == false && p.BookFee == 0).OrderByDescending(p => p.DocumentID).Take(30);
            return view_model;
        }
        public IEnumerable<DocumentEssential> searchByContent(string keyword)
        {
            string[] keywordarr = keyword.ToLower().Split(' ');
            IEnumerable<DocWeightModel> listdocuments = (from dw in db.DocWeights
                                                         join dword in db.DocWords on dw.WordID equals dword.WordID
                                                         where keywordarr.Contains(dword.Word.ToLower())
                                                         group dw by dw.DocID into g
                                                         orderby g.Sum(dw => dw.Weight) descending
                                                         select new DocWeightModel
                                                         {
                                                             DocID = g.Key,
                                                             Weight = g.Sum(dw => dw.Weight)

                                                         });
            var resultList = new List<long>();
            if (listdocuments.Count() > 0)
            {
                foreach (var item in listdocuments)
                {
                    resultList.Add(item.DocID);
                }
            }

            IEnumerable<DocumentEssential> result = (from doc in db.Documents
                                                     join df in db.DocumentsFiles
                                                     on doc.DocumentID equals df.DocumentID
                                                     where resultList.Contains(df.DocumentID) && df.Status == "Hiển thị" && df.IsHasInfo == true && df.IsDeleted == false
                                                     select new DocumentEssential
                                                     {
                                                         Title = doc.Title,
                                                         Contributor = doc.Contributor,
                                                         Coverage = doc.Coverage,
                                                         Description = doc.Description,
                                                         Format = doc.Format,
                                                         FormatID = df.FormatID.Value,
                                                         Identifier = doc.Identifier,
                                                         Language = doc.Language,
                                                         Relation = doc.Relation,
                                                         Resource = doc.Resource,
                                                         Subject = doc.Subject,
                                                         Right = doc.Right,
                                                         Type = doc.Type,
                                                         DocumentID = doc.DocumentID,
                                                         CategoryID = df.CategoryID.Value,
                                                         Status = df.Status,
                                                         BookFee = df.BookFee.Value,
                                                         Thumbnail = df.Thumbnail,
                                                         ViewCount = df.ViewCount.Value,
                                                         IsHasInfo = df.IsHasInfo.Value,
                                                         IsDeleted = df.IsDeleted.Value,
                                                         Publisher = doc.Publisher,
                                                         Creator = doc.Creator,
                                                         FileSource = df.FileSource,
                                                         Date = doc.Date
                                                     });


            IEnumerable<DocumentEssential> view_model = null;

            if (IsPremium())
            {
                view_model = result.Where(p => p.IsHasInfo == true && p.IsDeleted == false).Take(9);
            }
            else
                view_model = result.Where(p => p.IsHasInfo == true && p.IsDeleted == false && p.BookFee == 0).Take(9);

            return view_model;


        }


        public IEnumerable<DocumentEssential> getFromCategory(int id)
        {
            IEnumerable<DocumentEssential> view_model = null;
            IEnumerable<DocumentEssential> model = (from df in db.DocumentsFiles
                                                    join doc in db.Documents on df.DocumentID equals doc.DocumentID
                                                    where df.CategoryID == id && df.Status == "Hiển thị"
                                                    select new DocumentEssential
                                                    {
                                                        DocumentID = df.DocumentID,
                                                        BookFee = df.BookFee.Value,
                                                        CategoryID = df.CategoryID.Value,
                                                        Description = doc.Description,
                                                        FormatID = df.FormatID.Value,
                                                        IsDeleted = df.IsDeleted.Value,
                                                        Status = df.Status,
                                                        Subject = doc.Subject,
                                                        IsHasInfo = df.IsHasInfo.Value,
                                                        Language = doc.Language,
                                                        Thumbnail = df.Thumbnail,
                                                        Title = doc.Title,
                                                        ViewCount = df.ViewCount.Value,
                                                        Creator = doc.Creator,
                                                        Identifier = doc.Identifier,
                                                        Publisher = doc.Publisher,
                                                        Format = doc.Format,
                                                        FileSource = df.FileSource,
                                                        Date = doc.Date
                                                    });
            if (IsPremium())
            {
                view_model = model.Where(p => p.IsHasInfo == true && p.IsDeleted == false).OrderByDescending(p => p.DocumentID).Take(9);
            }
            else
                view_model = model.Where(p => p.IsHasInfo == true && p.IsDeleted == false && p.BookFee == 0).OrderByDescending(p => p.DocumentID).Take(9);
            return view_model;
        }

        public IEnumerable<DocumentEssential> getFromFormat(int id)
        {
            IEnumerable<DocumentEssential> view_model = null;
            IEnumerable<DocumentEssential> model = (from df in db.DocumentsFiles
                                                    join doc in db.Documents on df.DocumentID equals doc.DocumentID
                                                    where df.FormatID == id && df.Status == "Hiển thị"
                                                    select new DocumentEssential
                                                    {
                                                        DocumentID = df.DocumentID,
                                                        BookFee = df.BookFee.Value,
                                                        CategoryID = df.CategoryID.Value,
                                                        Description = doc.Description,
                                                        FormatID = df.FormatID.Value,
                                                        IsDeleted = df.IsDeleted.Value,
                                                        Status = df.Status,
                                                        Subject = doc.Subject,
                                                        IsHasInfo = df.IsHasInfo.Value,
                                                        Language = doc.Language,
                                                        Thumbnail = df.Thumbnail,
                                                        Title = doc.Title,
                                                        ViewCount = df.ViewCount.Value,
                                                        Creator = doc.Creator,
                                                        Identifier = doc.Identifier,
                                                        Publisher = doc.Publisher,
                                                        Format = doc.Format,
                                                        FileSource = df.FileSource,
                                                        Date = doc.Date
                                                    });

            if (IsPremium())
            {
                view_model = model.Where(p => p.IsHasInfo == true && p.IsDeleted == false).OrderByDescending(p => p.DocumentID).Take(9);
            }
            else
                view_model = model.Where(p => p.IsHasInfo == true && p.IsDeleted == false && p.BookFee == 0).OrderByDescending(p => p.DocumentID).Take(9);
            return view_model;
        }

        //Minus the balance of the user when he/she reads book
        public bool minusFee(long DocumentId, double fee)
        {
            long id = AuthManager.GetUser().UserId;
            auth_Users user = db.auth_Users.FirstOrDefault(p => p.UserId == id);
            if (user.Profile != null)
            {
                if (user.Profile.Balance >= fee)
                {
                    user.Profile.Balance = user.Profile.Balance - fee;
                    db.SaveChanges();
                    return true;
                }
                else if (fee == 0.0)
                    return true;
                else
                    return false;
            }
            return false;
        }

        //Update view count for statistical details
        public void DocumentStatisticUpdate(DocumentEssential doc)
        {
            DocumentStatistic statistic;
            if (doc.BookFee == 0)
                statistic = db.DocumentStatistics.FirstOrDefault(p => p.CateID == doc.CategoryID
                    && p.Year == DateTime.Now.Year && p.Type == "FreeDocumentView");
            else
                statistic = db.DocumentStatistics.FirstOrDefault(p => p.CateID == doc.CategoryID
                    && p.Year == DateTime.Now.Year && p.Type == "FeeDocumentView");
            if (statistic != null)
            {
                statistic.Value = statistic.Value + 1;
                db.SaveChanges();
            }
        }

        //All about authentication

        //Check if user is of type premium (need to pay) or not
        public bool IsPremium()
        {
            if (AuthManager.GetUser() != null)
            {
                var roles = AuthManager.GetUser().Roles;
                foreach (var role in roles)
                {
                    if (role.RoleName == "Premium")
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public bool IsAuthenticated()
        {
            if (AuthManager.GetUser() != null)
            {
                return true;
            }
            else
                return false;
        }

        public long getUserId()
        {
            return AuthManager.GetUser().UserId;
        }

        /**
         * All about searching
         * */
        public IEnumerable<DocumentEssential> SearchResult(string keyword, int attribute, int category, int format, int FeeType)
        {
            IEnumerable<DocumentEssential> result = null;
            /*
             * @author hungnv
             * Check keyword for search history first 
             * if keyword exist and search date < 5days ago
             * Then load result of last search
             */

            if (!isKeywordExist(keyword) || !isKeywordAvailable(keyword, 30))
            {
               
                //keyword not exist || expired keyword =>find in db
             

                    result = (from doc in db.Documents
                              join df in db.DocumentsFiles
                              on doc.DocumentID equals df.DocumentID
                              where df.Status == "Hiển thị" && df.IsHasInfo == true && df.IsDeleted == false
                              orderby df.ViewCount descending
                              select new DocumentEssential
                              {
                                  Title = doc.Title,
                                  Contributor = doc.Contributor,
                                  Coverage = doc.Coverage,
                                  Description = doc.Description,
                                  Format = doc.Format,
                                  FormatID = df.FormatID.Value,
                                  Identifier = doc.Identifier,
                                  Language = doc.Language,
                                  Relation = doc.Relation,
                                  Resource = doc.Resource,
                                  Subject = doc.Subject,
                                  Right = doc.Right,
                                  Type = doc.Type,
                                  DocumentID = doc.DocumentID,
                                  CategoryID = df.CategoryID.Value,
                                  Status = df.Status,
                                  BookFee = df.BookFee.Value,
                                  Thumbnail = df.Thumbnail,
                                  ViewCount = df.ViewCount.Value,
                                  IsHasInfo = df.IsHasInfo.Value,
                                  IsDeleted = df.IsDeleted.Value,
                                  Publisher = doc.Publisher,
                                  Creator = doc.Creator,
                                  FileSource = df.FileSource,
                                  Date = doc.Date
                              });

                }

            else 
                {
                    string searchHistoryResult = getResultFromSearchHistory(keyword);
                    string[] arr = searchHistoryResult.Split(',');
                    var resultList = new List<long>();
                    for (var i = 0; i < arr.Length; i++)
                    {
                        resultList.Add(long.Parse(arr[i]));
                    }

                    result = (from doc in db.Documents
                              join df in db.DocumentsFiles
                              on doc.DocumentID equals df.DocumentID
                              where resultList.Contains(df.DocumentID)
                              orderby df.ViewCount descending
                              select new DocumentEssential
                              {
                                  Title = doc.Title,
                                  Contributor = doc.Contributor,
                                  Coverage = doc.Coverage,
                                  Description = doc.Description,
                                  Format = doc.Format,
                                  FormatID = df.FormatID.Value,
                                  Identifier = doc.Identifier,
                                  Language = doc.Language,
                                  Relation = doc.Relation,
                                  Resource = doc.Resource,
                                  Subject = doc.Subject,
                                  Right = doc.Right,
                                  Type = doc.Type,
                                  DocumentID = doc.DocumentID,
                                  CategoryID = df.CategoryID.Value,
                                  Status = df.Status,
                                  BookFee = df.BookFee.Value,
                                  Thumbnail = df.Thumbnail,
                                  ViewCount = df.ViewCount.Value,
                                  IsHasInfo = df.IsHasInfo.Value,
                                  IsDeleted = df.IsDeleted.Value,
                                  Publisher = doc.Publisher,
                                  Creator = doc.Creator,
                                  FileSource = df.FileSource,
                                  Date = doc.Date
                              });

                    if (category == 0  && format == 0 && FeeType == 1)
                    {
                        return result;
                    }
                }

            
            //find in documentFile 
          
            switch (attribute)
            {
                case 0:
                    result = searchByContent(keyword);
                    break;
                case 1:
                    result = result.Where(p => p.Title != null && p.Title.ToLower().Contains(keyword.ToLower()));
                    break;
                case 2:
                    result = result.Where(p => p.Creator != null && p.Creator.ToLower().Contains(keyword.ToLower()));
                    break;
                case 3:
                    result = result.Where(p => p.Subject != null && p.Subject.ToLower().Contains(keyword.ToLower()));
                    break;
                case 4:
                    result = result.Where(p => p.Description != null && p.Description.ToLower().Contains(keyword.ToLower()));
                    break;
                case 5:
                    result = result.Where(p => p.Publisher != null && p.Publisher.ToLower().Contains(keyword.ToLower()));
                    break;
                case 6:
                    result = result.Where(p => p.Contributor != null && p.Contributor.ToLower().Contains(keyword.ToLower()));
                    break;
                case 7:
                    result = result.Where(p => p.Type != null && p.Type.ToLower().Contains(keyword.ToLower()));
                    break;
                case 8:
                    result = result.Where(p => p.Format != null && p.Format.ToLower().Contains(keyword.ToLower()));
                    break;
                case 9:
                    result = result.Where(p => p.Identifier != null && p.Identifier.ToLower().Contains(keyword.ToLower()));
                    break;
                case 10:
                    result = result.Where(p => p.Resource != null && p.Resource.ToLower().Contains(keyword.ToLower()));
                    break;
                case 11:
                    result = result.Where(p => p.Language != null && p.Language.ToLower().Contains(keyword.ToLower()));
                    break;
                case 12:
                    result = result.Where(p => p.Relation != null && p.Relation.ToLower().Contains(keyword.ToLower()));
                    break;
                case 13:
                    result = result.Where(p => p.Coverage != null && p.Coverage.ToLower().Contains(keyword.ToLower()));
                    break;
                case 14:
                    result = result.Where(p => p.Right != null && p.Right.ToLower().Contains(keyword.ToLower()));
                    break;

                default:
                    result = result.Where(p => p.Title != null && p.Title.ToLower().Contains(keyword.ToLower()));
                    break;
            }

            if (format != 0)
            {
                result = result.Where(p => p.FormatID == format);
            }
            if (category != 0)
            {
                result = result.Where(p => p.CategoryID == category);
            }

            switch (FeeType)
            {
                case 1:
                    result = result.Where(p => p.BookFee <= 0.0);
                    break;
                case 2:
                    result = result.Where(p => p.BookFee > 0.0);
                    break;
                default:
                    break;

            }
            //store result
            if (result.Count() >= 1)
            {
                saveSearchHistory(keyword, result);
            }
            return result;

        }
        /*@author: hungnv
         * Store search history for authenticated user
         */
        private void saveSearchHistory(string keyword, IEnumerable<DocumentEssential> result)
        {

            if (AuthManager.GetUser() != null && keyword != "")
            {
                string resultSet = getResultSet(result);

                SearchHistory history = new SearchHistory
                {
                    UserId = AuthManager.GetUser().UserId,
                    Keyword = keyword,
                    SearchDate = DateTime.Now,
                    ResultSet = resultSet
                };
                //new record add it
                if (!isKeywordExist(keyword))
                {
                    db.SearchHistories.AddObject(history);
                    db.SaveChanges();
                }
                //old record then update it with new result
                else
                {
                    updateExpiredKeyword(history);
                }

            }
        }
        /*@author: hungnv
            * check for keyword existence
            */
        private Boolean isKeywordExist(string keyword)
        {
            if (db.SearchHistories.FirstOrDefault(p => p.Keyword == keyword) != null)
                return true;
            else
                return false;
        }
        /*@author hungnv
         * Keyword is available only if SearchDate<numOfdays
         */
        private Boolean isKeywordAvailable(string keyword, int numOfDays = 6)
        {
            SearchHistory sh = db.SearchHistories.FirstOrDefault(p => p.Keyword == keyword);
            if (sh.SearchDate.Year != DateTime.Now.Year || sh.SearchDate.Month != DateTime.Now.Month)
                return false;
            //true when searchDate<numOfDays ago
            return (DateTime.Now.Day - sh.SearchDate.Day) < numOfDays;
        }
        /*@author hungnv
        * update existing keyword
        */
        private void updateExpiredKeyword(SearchHistory newSearchHistory)
        {
            if (AuthManager.GetUser() != null && newSearchHistory.Keyword != "")
            {
                SearchHistory sh = db.SearchHistories.FirstOrDefault(p => p.Keyword == newSearchHistory.Keyword);
                sh.SearchDate = newSearchHistory.SearchDate;
                sh.ResultSet = newSearchHistory.ResultSet;
                sh.UserId = newSearchHistory.UserId;
                db.SaveChanges();
            }

        }

        /*@author: hungnv
          * get resultSet contain Id of document by existency keyword
          */
        private string getResultFromSearchHistory(string keyword)
        {

            return db.SearchHistories.FirstOrDefault(p => p.Keyword == keyword).ResultSet;

        }
        /*@author: hungnv
          * get resultSet contain Id of document by Search Result
          */
        private string getResultSet(IEnumerable<DocumentEssential> result)
        {
            string resultSet = "";

            for (var i = 0; i < result.Count() - 1; i++)
            {
                resultSet += result.ElementAt(i).DocumentID + ",";
            }

            resultSet += result.ElementAt(result.Count() - 1).DocumentID;

            return resultSet;
        }

        private IEnumerable<DocumentEssential> getFromAllFields(IEnumerable<DocumentEssential> result, string keyword)
        {
            keyword = keyword.ToLower();
            result = result.Where(p => p.Title != null && p.Title.ToLower().Contains(keyword)
                || p.Creator != null && p.Creator.ToLower().Contains(keyword)
                || p.Subject != null && p.Subject.ToLower().Contains(keyword)
                || p.Description != null && p.Description.ToLower().Contains(keyword)
                || p.Publisher != null && p.Publisher.ToLower().Contains(keyword)
                || p.Contributor != null && p.Contributor.ToLower().Contains(keyword)
                || p.Type != null && p.Type.ToLower().Contains(keyword)
                || p.Format != null && p.Format.ToLower().Contains(keyword)
                || p.Identifier != null && p.Identifier.ToLower().Contains(keyword)
                || p.Resource != null && p.Resource.ToLower().Contains(keyword)
                || p.Language != null && p.Language.ToLower().Contains(keyword)
                || p.Relation != null && p.Relation.ToLower().Contains(keyword)
                || p.Coverage != null && p.Coverage.ToLower().Contains(keyword)
                || p.Right != null && p.Right.ToLower().Contains(keyword)
                );
            return result;
        }
    }
}
