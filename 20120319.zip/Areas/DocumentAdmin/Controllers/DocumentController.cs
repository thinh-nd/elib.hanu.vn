﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Entity;
using System.Web;
using System.Web.Mvc;
using QML.Library;
using QML.Library.Utilities;
using QML.Library.Helpers;
using QML.Library.Auth;
using QML.Library.Base.Controllers;
using QML.Library.Attributes;
using QML.Web.UI.Areas.DocumentAdmin.Helpers;
using QML.Web.UI.Areas.DocumentAdmin.Models;
using System.IO;
using System.Web.Helpers;

namespace QML.Web.UI.Areas.DocumentAdmin.Controllers
{
    public class DocumentController : SecuredController
    {
        //
        // GET: /DocumentAdmin/Document/
        HanuELibraryEntities db = new HanuELibraryEntities();

        [Menu(Title = "Danh sách tài liệu", Path = "Tài liệu", Order = 1)]
        public ActionResult Index(long? id_cate = 0)
        {
            IEnumerable<DocumentsFileModel> document;
            DocumentCategoryTreeViewHelper tree = new DocumentCategoryTreeViewHelper();
            // By Category
            if (id_cate != 0)
            {
                tree.getIdRelatives(Int32.Parse(id_cate.ToString()));
                List<int> list = tree.list_id_relatives;
                list.Add(Int32.Parse(id_cate.ToString()));
                //list.Add(1); list.Add(3); list.Add(4);
                document = (from d in db.DocumentsFiles
                            where list.Contains(d.CategoryID ?? 0) && d.IsDeleted == false
                            orderby d.CreatedDate descending
                            select new DocumentsFileModel
                            {
                                DocumentID = d.DocumentID,
                                FileName = d.FileName,
                                CategoryID = d.CategoryID.Value,
                                FormatID = d.FormatID.Value,
                                Size = d.Size.Value,
                                CheckHasInfo = d.IsHasInfo.Value == true ? "checked='checked'" : "",
                                CreatedDate = d.CreatedDate.Value,
                                Status = d.Status
                            });
            }
            else
            {
                document = (from d in db.DocumentsFiles
                            where d.IsDeleted == false
                            orderby d.CreatedDate descending
                            select new DocumentsFileModel
                            {
                                DocumentID = d.DocumentID,
                                FileName = d.FileName,
                                CategoryID = d.CategoryID.Value,
                                FormatID = d.FormatID.Value,
                                Size = d.Size.Value,
                                CheckHasInfo = d.IsHasInfo.Value == true ? "checked='checked'" : "",
                                CreatedDate = d.CreatedDate.Value,
                                Status = d.Status
                            });
            }


            tree.renderTreeView(0, Url.Action("Index"));
            ViewBag.tree_cate = tree.trees;
            ViewBag.id_cate = id_cate;
            ViewBag.name_cate = DocumentsHelper.getCategoryName(Int32.Parse(id_cate.ToString()));
            return View(document);
        }

        [HttpPost]
        public ActionResult Management(FormCollection collection)
        {
            string[] listID = collection["idValue"].Split(',');
            DocumentsFile document;
            long id_document = Int64.Parse(listID[0]);
            switch (collection["actionName"])
            {
                case "cataloging":
                    return RedirectToAction("ExtraInfo", new { id = Int64.Parse(listID[0]) });
                    
                case "thumbnail":

                    DocumentsFileModel df = db.DocumentsFiles.Where(p => p.DocumentID == id_document).Select(p => new DocumentsFileModel
                    {
                        Thumbnail = p.Thumbnail,
                        FileName = p.FileName,
                        DocumentID = p.DocumentID
                    }).FirstOrDefault();
                    ViewBag.thumbnail = df.Thumbnail;
                    ViewBag.DocumentName = df.FileName;
                    ViewBag.id = df.DocumentID;
                    return View("../Document/Thumbnail");
                   
                case "moveCate":
                    // Call TreeViewHelper
                    DocumentCategoryTreeViewHelper obj = new DocumentCategoryTreeViewHelper();
                    obj.BuildHierarchicalList(0, ""); // Build dropdownList
                    List<DocumentCategoriesModel> items = obj.DocumentList;
                    ViewBag.ListID = collection["idValue"];
                    ViewBag.ParentList = new SelectList(items, "CategoryID", "CategoryName");
                    return View("../Document/moveCate");
                    
                case "setStatus":
                    ViewBag.ListID = collection["idValue"];
                    var values = new[]
                    {
                        new { Value = "Không hiển thị", Text = "Không hiển thị" },
                        new { Value = "Hiển thị", Text = "Hiển thị" },
                        new { Value = "Mật", Text = "Mật" },
                    };
                    ViewBag.StatusList = new SelectList(values, "Value", "Text");
                    return View("../Document/setStatus");
                    
                case "setFee":

                    DocumentsFileModel doc = db.DocumentsFiles.Where(p => p.DocumentID == id_document).Select(p => new DocumentsFileModel
                    {
                        BookFee = p.BookFee.Value,
                        FileName = p.FileName,
                        DocumentID = p.DocumentID
                    }).FirstOrDefault();
                    ViewBag.DocumentFee = doc.BookFee;
                    ViewBag.DocumentName = doc.FileName;
                    ViewBag.id = doc.DocumentID;
                    return View("../Document/setFee");
                  
                case "deleteCurrent":

                    //List<int> ListID = new List<int>();
                    foreach (string item in listID)
                    {
                        int id_doc = Int32.Parse(item);
                        document = db.DocumentsFiles.Where(d => d.DocumentID == id_doc).FirstOrDefault();
                        document.IsDeleted = true;
                    }
                    db.SaveChanges();
                    return RedirectToAction("Index");
                    
                case "deletePermanent":
                    foreach (string item in listID)
                    {
                        int id_doc = Int32.Parse(item);
                        document = db.DocumentsFiles.Where(d => d.DocumentID == id_doc).FirstOrDefault();
                        db.DocumentsFiles.DeleteObject(document);
                    }
                    db.SaveChanges();
                    return RedirectToAction("Index");
                    
                default:
                    return RedirectToAction("Index");
                    
            }

            //return RedirectToAction("Index", new { result = collection["actionName"], count = listID.Count() });
        }

        [HttpPost]
        public ActionResult Thumbnail(FormCollection collection)
        {

            long id = Int64.Parse(collection["DocumentID"]);
            DocumentsFile entity = db.DocumentsFiles.FirstOrDefault(p => p.DocumentID == id);
            // TODO: Add logic here

            // File Upload     
            var file = WebImage.GetImageFromRequest();
            string fileName = "";
            if (file != null)
            {
                fileName = DateTime.Now.Ticks.ToString() + Path.GetFileName(file.FileName);
                var path = Path.Combine(Server.MapPath("~/uploads"), fileName);
                file.Save(path);
                if (Path.GetExtension(file.FileName) == "gif")
                {
                    fileName = fileName + ".gif";
                }
                entity.Thumbnail = fileName;
                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult setFee(FormCollection collection)
        {

            long id = Int64.Parse(collection["DocumentID"]);
            DocumentsFile entity = db.DocumentsFiles.FirstOrDefault(p => p.DocumentID == id);
            entity.BookFee = float.Parse(collection["fee"]);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult setStatus(FormCollection collection)
        {

            DocumentsFile document;
            string[] list = collection["listID"].Split(',');
            foreach (string item in list)
            {
                int id_doc = Int32.Parse(item);
                document = db.DocumentsFiles.Where(d => d.DocumentID == id_doc).FirstOrDefault();
                document.Status = collection["Status"];
            }
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult moveCate(FormCollection collection)
        {

            DocumentsFile document;
            int id_cate = Int32.Parse(collection["CateID"]);
            string[] list = collection["listID"].Split(',');
            //List<int> ListID = new List<int>();
            foreach (string item in list)
            {
                int id_doc = Int32.Parse(item);
                document = db.DocumentsFiles.Where(d => d.DocumentID == id_doc).FirstOrDefault();
                document.CategoryID = id_cate;
            }
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        /*
        public ActionResult Search(string attribute, string keyword, long? id_cate = 0)
        {
            DocumentCategoryTreeViewHelper tree = new DocumentCategoryTreeViewHelper();
            List<DocumentsFile> document = db.DocumentsFiles.ToList();
            IEnumerable<DocumentsFileModel> models;
            string filter = "";
            if (string.IsNullOrEmpty(keyword))
            {
                return RedirectToAction("Index");
            }

            switch (attribute)
            {
                case "Publisher":
                    document = document.Where(d => d.Publisher.ToUpper().Contains(keyword.ToUpper())).ToList();
                    filter += "Nhà xuất bản";
                    break;
                case "Type":
                    document = document.Where(d => d.Type.ToUpper().Contains(keyword.ToUpper())).ToList();
                    filter += "Thể loại";
                    break;
                case "Creator":
                    document = document.Where(d => d.Creator.ToUpper().Contains(keyword.ToUpper())).ToList();
                    filter += "Tác giả";
                    break;
                default:
                    document = document.Where(d => d.Title.ToUpper().Contains(keyword.ToUpper())).ToList();
                    filter += "Tiêu đề tài liệu";
                    break;
            }
            if (id_cate != 0)
            {
                document = document.Where(d => d.SubjectId == id_cate).ToList();
            }

            models = document.Join(
                                        db.DocumentsExtraInfoes,
                                        d => d.DocumentID,
                                        de => de.DocumentID,
                                        (d, de) => new DocumentModel
                                        {
                                            DocumentID = d.DocumentID,
                                            Title = d.Title,
                                            SubjectID = d.SubjectId.Value,
                                            Creator = d.Creator,
                                            Type = d.Type,
                                            Format = d.Format.Value,
                                            Status = de.Status.Value
                                        }
                                       );
            tree.renderTreeView(0, Url.Action("Index"));
            ViewBag.tree_cate = tree.trees;
            ViewBag.id_cate = id_cate;
            ViewBag.name_cate = DocumentsHelper.getCategoryName(Int32.Parse(id_cate.ToString()));
            ViewBag.filter = filter;
            ViewBag.keyword = keyword;
            return View("../Document/Index", models);
        }
        */
        //
        // GET: /DocumentAdmin/Document/Details/5
        /*
        public ActionResult Check(long id)
        {
            DocumentsExtraInfo entity = db.DocumentsExtraInfoes.FirstOrDefault(p => p.DocumentID == id);
            if (entity.Status == true)
            {
                entity.Status = false;
            }
            else
            {
                entity.Status = true;
            }
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        */
        //
        // GET: /DocumentAdmin/Document/Create

        public ActionResult Filter(string attribute, string value, long? id_cate = 0)
        {
            DocumentCategoryTreeViewHelper tree = new DocumentCategoryTreeViewHelper();
            List<DocumentsFile> document = db.DocumentsFiles.ToList();
            IEnumerable<DocumentsFileModel> models;
            string header = "Lọc theo thuộc tính ";
            if (attribute == "Status")
            {
                header += "<b>Trạng thái: </b>";
                if (value == "public")
                {
                    document = document.Where(d => d.Status == "Hiển thị").ToList();
                    header += "<i>Hiển thị</i>";
                }
                else if (value == "unpublic")
                {
                    document = document.Where(d => d.Status == "Không hiển thị").ToList();
                    header += "<i>Không hiển thị</i>";
                }
                else if (value == "private")
                {
                    document = document.Where(d => d.Status == "Mật").ToList();
                    header += "<i>Mật</i>";
                }

            }
            else if (attribute == "Catalogue")
            {

                if (value == "cataloged")
                {
                    document = document.Where(d => d.IsHasInfo == true).ToList();
                    header += "<b>Đã biên mục</b>";
                }
                else if (value == "notcataloged")
                {
                    document = document.Where(d => d.IsHasInfo == false).ToList();
                    header += "<b>Chưa biên mục</b>";
                }
            }
            else
            {
               // return RedirectToAction("Index");
                if (value == "fee")
                {
                    document = document.Where(d => d.BookFee > 0).ToList();
                    header += "<b>Thu phí</b>";
                }
                else if (value == "free")
                {
                    document = document.Where(d => d.BookFee == 0).ToList();
                    header += "<b>Miễn phí</b>";
                }
            }

            if (id_cate != 0)
            {
                document = document.Where(d => d.CategoryID == id_cate).ToList();
            }

            models = document.Where(d => d.IsDeleted == false).Select(d => new DocumentsFileModel
            {
                DocumentID = d.DocumentID,
                FileName = d.FileName,
                CategoryID = d.CategoryID.Value,
                FormatID = d.FormatID.Value,
                Size = d.Size.Value,
                CheckHasInfo = d.IsHasInfo.Value == true ? "checked='checked'" : "",
                CreatedDate = d.CreatedDate.Value,
                Status = d.Status
            }).OrderByDescending(d => d.CreatedDate);

            tree.renderTreeView(0, Url.Action("Index"));
            ViewBag.tree_cate = tree.trees;
            ViewBag.id_cate = id_cate;
            ViewBag.name_cate = DocumentsHelper.getCategoryName(Int32.Parse(id_cate.ToString()));
            ViewBag.header = header;
            return View("../Document/Index", models);
        }

        public ActionResult Create()
        {
            // Call TreeViewHelper
            DocumentCategoryTreeViewHelper obj = new DocumentCategoryTreeViewHelper();
            obj.BuildHierarchicalList(0, ""); // Build dropdownList
            List<DocumentCategoriesModel> items = obj.DocumentList;
            List<DocumentFormat> type_items = DocumentsHelper.GetDocumentTypeList();
            // Assign ViewBag            
            ViewBag.ParentList = new SelectList(items, "CategoryID", "CategoryName");
            ViewBag.TypeList = new SelectList(type_items, "DocumentFormatID", "Name");

            //DocumentModel model = new DocumentModel();
            //model.Date = DateTime.Today;
            return View();
        }

        //
        // POST: /DocumentAdmin/Document/Create

        [HttpPost]
        public ActionResult Create(DocumentsFileModel model, HttpPostedFileBase file)
        {
            try
            {
                if ((file != null) && (file.ContentLength > 0))
                {
                    DocumentsFile entity = new DocumentsFile();
                    entity.CategoryID = model.CategoryID;
                    entity.FormatID = model.FormatID;
                    string fileName = Path.GetFileName(file.FileName);
                    string extension ="";
                    if(!string.IsNullOrEmpty(fileName))
                    {
                        fileName = fileName.Replace(" ", "_");
                        extension = fileName.Split('.')[(fileName.Split('.').Length - 1)].ToLower();
                    }
                  
                    entity.FileName = fileName;
                    var path = Path.Combine(Server.MapPath("~/Resources"), fileName);
                    file.SaveAs(path);
                    FileInfo finfo = new FileInfo(HttpContext.Server.MapPath("~/Resources/" + fileName));
                    long FileInBytes = finfo.Length;
                    long FileInKB = finfo.Length / 1024;
                    entity.Size = FileInKB;
                
                    switch (extension)
                    {
                        case "pdf":
                               entity.FileSource = fileName.Replace("."+extension,"") + ".swf";
                                entity.Thumbnail = "pdf.png";
                            break;
                        case "mp3":
                             entity.FileSource = fileName;
                              entity.Thumbnail = "mp3.png";
                            break;
                        case "swf":
                            return RedirectToAction("Index");
                        case "default":
                              entity.FileSource = fileName;
                              entity.Thumbnail = "avi.png";
                            break;

                    }      

                    entity.BookFee = 0;
                    entity.ViewCount = 0;
                    entity.Status = "Không hiển thị";
                    entity.IsDeleted = false;
                    entity.IsHasInfo = false;
                    entity.CreatedDate = entity.LastModifiedDate = DateTime.Now;
                    entity.CreatedUser = entity.LastModifiedUser = "root";
                    db.DocumentsFiles.AddObject(entity);
                    db.SaveChanges();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return RedirectToAction("Index");
        }

        public ActionResult ExtraInfo(long id)
        {
            DocumentModel model = db.Documents.Where(d => d.DocumentID == id).Select(d => new DocumentModel
            {
                Title = d.Title,
                Creator = d.Creator,
                Subject = d.Subject,
                Description = d.Description,
                Publisher = d.Publisher,
                Contributor = d.Contributor,
                Date = d.Date.Value == null ? new DateTime(1000, 1, 1) : d.Date.Value,
                Type = d.Type,
                Format = d.Format,
                Identifier = d.Identifier,
                Resource = d.Resource,
                Language = d.Language,
                Relation = d.Relation,
                Coverage = d.Coverage,
                Right = d.Right,
            }).FirstOrDefault();
            var df = (from d in db.DocumentsFiles
                      where d.DocumentID == id
                      select d).SingleOrDefault();
            ViewBag.DocumentName = df.FileName;
            return View(model);
        }

        //
        // POST: /DocumentAdmin/Document/Edit/5

        [HttpPost]
        public ActionResult ExtraInfo(long id, DocumentModel model)
        {
            Document entity = db.Documents.FirstOrDefault(p => p.DocumentID == id);
            if (entity != null)
            {
                entity.Title = model.Title;
                entity.Creator = model.Creator;
                entity.Subject = model.Subject;
                entity.Description = model.Description;
                entity.Publisher = model.Publisher;
                entity.Contributor = model.Contributor;
                entity.Date = model.Date;
                entity.Type = model.Type;
                entity.Format = model.Format;
                entity.Identifier = model.Identifier;
                entity.Resource = model.Resource;
                entity.Language = model.Language;
                entity.Relation = model.Relation;
                entity.Coverage = model.Coverage;
                entity.Right = model.Right;
            }
            else
            {
                Document doc = new Document();
                doc.DocumentID = id;
                doc.Title = model.Title;
                doc.Creator = model.Creator;
                doc.Subject = model.Subject;
                doc.Description = model.Description;
                doc.Publisher = model.Publisher;
                doc.Contributor = model.Contributor;
                doc.Date = model.Date;
                doc.Type = model.Type;
                doc.Format = model.Format;
                doc.Identifier = model.Identifier;
                doc.Resource = model.Resource;
                doc.Language = model.Language;
                doc.Relation = model.Relation;
                doc.Coverage = model.Coverage;
                doc.Right = model.Right;
                db.Documents.AddObject(doc);
                DocumentsFile docfile = db.DocumentsFiles.FirstOrDefault(p => p.DocumentID == id);
                docfile.IsHasInfo = true;
            }
            db.SaveChanges();
            return RedirectToAction("Index");

        }


        //
        // GET: /DocumentAdmin/Document/Edit/5

        public ActionResult Edit(long id)
        {
            // Fetch model
            DocumentsFile entity = db.DocumentsFiles.FirstOrDefault(p => p.DocumentID == id);

            // Call TreeViewHelper
            DocumentCategoryTreeViewHelper obj = new DocumentCategoryTreeViewHelper();
            obj.BuildHierarchicalList(0, ""); // Build dropdownList
            List<DocumentCategoriesModel> items = obj.DocumentList;
            List<DocumentFormat> type_items = DocumentsHelper.GetDocumentTypeList();
            // Assign ViewBag            
            ViewBag.ParentList = new SelectList(items, "CategoryID", "CategoryName");
            ViewBag.TypeList = new SelectList(type_items, "DocumentFormatID", "Name");

            return View(entity);
        }

        //
        // POST: /DocumentAdmin/Document/Edit/5
        /*
        [HttpPost]
        public ActionResult Edit(long id, DocumentsFileModel model, HttpPostedFileBase file)
        {
                    DocumentsFile entity = db.DocumentsFiles.FirstOrDefault(p => p.DocumentID == id);
                    entity.FileName = model.FileName;
                    entity.Creator = model.Creator;
                    entity.SubjectId = model.SubjectId;
                    entity.Description = model.Description;
                    entity.Publisher = model.Publisher;
                    entity.Contributor = model.Contributor;
                    entity.Date = model.Date;
                    entity.Type = model.Type;
                    entity.Format = model.Format;
                    entity.Resource = model.Resource;
                    entity.Language = model.Language;
                    entity.Relation = model.Relation;
                    entity.Coverage = model.Coverage;
                    entity.CopyRight = model.CopyRight;
                    string fileName = "";
                    if ((file != null) && (file.ContentLength > 0))
                    {
                        fileName = DateTime.Now.Ticks.ToString() + Path.GetFileName(file.FileName);
                        var path = Path.Combine(Server.MapPath("~/Resources"), fileName);
                        file.SaveAs(path);
                        if (fileName.Split('.')[(fileName.Split('.').Length - 1)].ToLower() == "pdf")
                        {

                            // Convert to swf                
                            string cmdStr = HttpContext.Server.MapPath("~/pdf2swf.exe");
                            string savePath = HttpContext.Server.MapPath("~/Resources");
                            string filePath = HttpContext.Server.MapPath("~/Resources/" + fileName);
                            string args = " -t " + filePath + " -o " + savePath + "\\" + fileName + ".swf";
                            DocumentsHelper.ExecuteCmd(cmdStr, args);

                            entity.Identifier = fileName + ".swf";
                        }
                        else
                        {
                            entity.Identifier = fileName;
                        }
                
                     }
                     db.SaveChanges();
                     return RedirectToAction("ExtraInfo", new { id = entity.DocumentID });
            
        }
         * */

        //
        // GET: /DocumentAdmin/Document/Delete/5

        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /DocumentAdmin/Document/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            return RedirectToAction("Index");

        }

        [Menu(Title = "Thống kê hệ thống", Path = "Thống kê")]
        public ActionResult SystemStatistics(string viewYear, string docCatId, string viewMonth, string docType = "Fee")
        {
            int? paramYear = GetInt(viewYear) ?? DateTime.Now.Year;
            int? categoryId = GetInt(docCatId);
            int? paramMonth = GetInt(viewMonth);
            ViewBag.tableTitle = "Năm: " + paramYear;
            IEnumerable<SystemStatisticModel> systemStatistic = null;

            systemStatistic = (from viewhistory in db.ViewHistories
                               where viewhistory.Year == paramYear && viewhistory.Type.Equals(docType, StringComparison.OrdinalIgnoreCase)
                               group viewhistory by new { viewhistory.Month, viewhistory.CatId } into grp
                               select new SystemStatisticModel
                               {
                                   CateId = grp.Key.CatId.Value,
                                   Views = grp.Count(),
                                   Month = grp.Key.Month.Value,
                                   Fee = grp.Sum(doc => doc.Fee),

                               }
                              );
            if (paramMonth != null)
            {
                systemStatistic = systemStatistic.Where(d => d.Month == paramMonth);
                ViewBag.tableTitle += " Tháng: " + viewMonth;
            }

            if (categoryId != null)
            {
                systemStatistic = systemStatistic.Where(d => d.CateId == categoryId);
                ViewBag.tableTitle += " Chuyên mục: " + DocumentsHelper.getCategoryNameById(categoryId);
            }
            String vnDocTypeTitle = docType.Equals("Fee", StringComparison.OrdinalIgnoreCase) ? "Trả phí" : "Miễn phí";
            ViewBag.tableTitle += " Thể loại: " + vnDocTypeTitle;

            ViewBag.Nums = systemStatistic.Count();
            // Call TreeViewHelper
            DocumentCategoryTreeViewHelper obj = new DocumentCategoryTreeViewHelper();
            obj.BuildHierarchicalList(0, ""); // Build dropdownList
            List<DocumentCategoriesModel> items = obj.DocumentList;
            // Assign ViewBag            
            ViewBag.ParentList = new SelectList(items, "CategoryID", "CategoryName");
            ViewBag.YearListItem = DocumentsHelper.GetYearListData();
            ViewBag.MonthListItem = DocumentsHelper.GetMonthListData();
            ViewBag.TypeListitem = DocumentsHelper.GetDocTypeListData();
            return View(systemStatistic);

        }
        public static int? GetInt(string stringVal)
        {
            int? value;
            int dummy;
            if (Int32.TryParse(stringVal, out dummy))
            {
                value = dummy;
            }
            else
            {
                value = null;
            }
            return value;
        }
        [Menu(Title = "Lượt xem hàng năm", Path = "Thống kê", Order = 3)]
        public ActionResult StatisticDocumentView(string Cate_Id)
        {
            IEnumerable<DocumentSatisticModel> documentstatistic;
            string paramYears = "";
            string feedoc = "";
            string freedoc = "";
            if (string.IsNullOrEmpty(Cate_Id) == true)
            {
                documentstatistic = (from ds in db.DocumentStatistics
                                     where ds.Type == "FeeDocumentView" || ds.Type == "FreeDocumentView"
                                     group ds by new { ds.Year, ds.Type }
                                         into grp
                                         select new DocumentSatisticModel
                                         {
                                             Year = grp.Key.Year.Value,
                                             Type = grp.Key.Type,
                                             Value = grp.Sum(t => t.Value).Value
                                         }).ToList();
                var paramYear = (from y in db.DocumentStatistics
                                 where y.Type == "FeeDocumentView" || y.Type == "FreeDocumentView"
                                 select new { paramYear = y.Year }).Distinct().ToList();
                for (int i = 0; i < paramYear.Count(); i++)
                {
                    if (i != paramYear.Count() - 1)
                    {
                        paramYears += paramYear.ElementAt(i).paramYear.Value + ", ";

                    }
                    else
                    {
                        paramYears += paramYear.ElementAt(i).paramYear.Value;

                    }
                }
                for (int i = 0; i < documentstatistic.Count(); i++)
                {
                    //if (i != documentstatistic.Count() - 1)
                    //{
                    if (documentstatistic.ElementAt(i).Type == "FeeDocumentView")
                    {
                        feedoc += documentstatistic.ElementAt(i).Value + ", ";
                    }
                    else
                    {
                        freedoc += documentstatistic.ElementAt(i).Value + ", ";
                    }
                }
                ViewBag.name_cate = "Toàn bộ chuyên mục";
            }
            else
            {
                int cate_id = Int32.Parse(Cate_Id);
                ViewBag.name_cate = "Chuyên mục: " + DocumentsHelper.getCategoryName(cate_id);
                documentstatistic = (from ds in db.DocumentStatistics
                                     where (ds.Type == "FeeDocumentView" || ds.Type == "FreeDocumentView") && ds.CateID == cate_id
                                     group ds by new { ds.Year, ds.Type }
                                         into grp
                                         select new DocumentSatisticModel
                                         {
                                             Year = grp.Key.Year.Value,
                                             Type = grp.Key.Type,
                                             Value = grp.Sum(t => t.Value).Value
                                         }).ToList();
                var paramYear = (from y in db.DocumentStatistics
                                 where (y.Type == "FeeDocumentView" || y.Type == "FreeDocumentView") && y.CateID == cate_id
                                 select new { paramYear = y.Year }).Distinct().ToList();
                for (int i = 0; i < paramYear.Count(); i++)
                {
                    if (i != paramYear.Count() - 1)
                    {
                        paramYears += paramYear.ElementAt(i).paramYear.Value + ", ";

                    }
                    else
                    {
                        paramYears += paramYear.ElementAt(i).paramYear.Value;

                    }
                }
                for (int i = 0; i < documentstatistic.Count(); i++)
                {
                    //if (i != documentstatistic.Count() - 1)
                    //{
                    if (documentstatistic.ElementAt(i).Type == "FeeDocumentView")
                    {
                        feedoc += documentstatistic.ElementAt(i).Value + ", ";
                    }
                    else
                    {
                        freedoc += documentstatistic.ElementAt(i).Value + ", ";
                    }
                }
            }


            // Call TreeViewHelper
            DocumentCategoryTreeViewHelper obj = new DocumentCategoryTreeViewHelper();
            obj.BuildHierarchicalList(0, ""); // Build dropdownList
            List<DocumentCategoriesModel> items = obj.DocumentList;
            // Assign ViewBag            
            ViewBag.ParentList = new SelectList(items, "CategoryID", "CategoryName");
            ViewBag.paramYear = paramYears;
            ViewBag.feedoc = feedoc;
            ViewBag.freedoc = freedoc;
            return View(documentstatistic);
        }

        [Menu(Title = "Các đầu mục tài liệu", Path = "Thống kê", Order = 2)]
        public ActionResult StatisticDocumentNum(string Year)
        {
            DocumentCategoryTreeViewHelper tree = new DocumentCategoryTreeViewHelper();
            int total = 0;
            if (string.IsNullOrEmpty(Year) == true)
            {
                tree.renderTreeView(0, "#", 0, true);
                total = db.DocumentsFiles.Where(d => d.IsDeleted == false).Count();
            }
            else
            {
                int paramYear = Int32.Parse(Year);
                total = db.DocumentsFiles.Where(d => d.IsDeleted == false && d.CreatedDate.Value.Year == paramYear).Count();
                tree.renderTreeView(0, "#", paramYear, true);
            }
            ViewBag.tree_cate = tree.trees;
            var paramYears = (from y in db.DocumentsFiles
                              where y.IsDeleted == false
                              select new { paramYear = y.CreatedDate.Value.Year }).Distinct().ToList();
            ViewBag.YearList = new SelectList(paramYears, "paramYear", "paramYear");
            ViewBag.Total = total;
            return View();
        }

        [Menu(Title = "Khoản thu phí hàng năm", Path = "Thống kê", Order = 1)]
        public ActionResult StatisticIncome()
        {
            string amount = "";
            string paramYear = "";
            //var income = (from ds in db.DocumentStatistics
            //              where ds.Type == "income"
            //              orderby ds.Year descending
            //              select new
            //              {
            //                  paramYear = ds.Year.Value,
            //                  amount = ds.Value
            //              }).Distinct().ToList();
            var income = db.DocumentStatistics.Where(ds => ds.Type == "income").Select(ds => new
            {
                paramYear = ds.Year.Value,
                amount = ds.Value
            }).OrderBy(ds => ds.paramYear).ToList();
            for (int i = 0; i < income.Count(); i++)
            {

                if (i != (income.Count() - 1))
                {
                    amount += income.ElementAt(i).amount + ", ";
                    paramYear += income.ElementAt(i).paramYear + ", ";
                }
                else
                {
                    amount += income.ElementAt(i).amount;
                    paramYear += income.ElementAt(i).paramYear;
                }
            }

            ViewBag.paramYear = paramYear;
            ViewBag.income = amount;

            return View();
        }
    }
}
