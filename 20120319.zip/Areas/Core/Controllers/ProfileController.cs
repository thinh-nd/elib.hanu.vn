﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QML.Web.UI;
using QML.Library.Base.Controllers;

namespace QML.Web.UI.Areas.Core.Controllers
{ 
    public class ProfileController : SecuredController
    {
        private HanuELibraryEntities db = new HanuELibraryEntities();
        
        //
        // GET: /DocumentAdmin/Profile/Edit/5
 
        public ActionResult Edit(long id)
        {
            if (db.Profiles.FirstOrDefault(p => p.UserId == id) == null)
            {
                Profile new_profile = new Profile
                {
                    UserId = id,
                    Balance = 0.0,
                    CreatedDate = DateTime.Now,
                    LastModifiedDate = DateTime.Now,
                    CreatedUser = AuthManager.GetUser().UserId,
                    LastModifiedUser = AuthManager.GetUser().UserId,
                    Status = true,
                    Email = " "
                };
                auth_Users user = db.auth_Users.FirstOrDefault(p => p.UserId == id);
                db.Profiles.AddObject(new_profile);
                user.Profile = new_profile;           
                db.SaveChanges();
                ViewBag.UserId = new SelectList(db.auth_Users, "UserId", "Username", new_profile.UserId);
                return View(new_profile);
            }
            else
            {
                Profile profile = db.Profiles.FirstOrDefault(p => p.UserId == id);
                ViewBag.UserId = new SelectList(db.auth_Users, "UserId", "Username", profile.UserId);
                return View(profile);
            }
        }

        //
        // POST: /DocumentAdmin/Profile/Edit/5

        [HttpPost]
        public ActionResult Edit(Profile profile)
        {
            if (ModelState.IsValid)
            {
                double balance = profile.Balance;
                DocumentStatistic statistic = db.DocumentStatistics.FirstOrDefault(p => p.CateID == null && p.Type == "income" && p.Year == DateTime.Now.Year);
                statistic.Value = statistic.Value + balance;
                profile.LastModifiedDate = DateTime.Now;
                profile.LastModifiedUser = AuthManager.GetUser().UserId;
                db.Profiles.Attach(profile);
                db.ObjectStateManager.ChangeObjectState(statistic, EntityState.Modified);
                db.ObjectStateManager.ChangeObjectState(profile, EntityState.Modified);
                db.SaveChanges();
                return RedirectToAction("UsersList", "User");
            }
            ViewBag.UserId = new SelectList(db.auth_Users, "UserId", "Username", profile.UserId);
            return View(profile);
        }

        public ActionResult DeleteUser(long id)
        {
            auth_Users user = db.auth_Users.FirstOrDefault(p => p.UserId == id);
            Profile profile = db.Profiles.FirstOrDefault(p => p.UserId == id);
            db.Profiles.DeleteObject(profile);
            db.auth_Users.DeleteObject(user);
            db.SaveChanges();
            return RedirectToAction("UsersList", "User");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

    }
}