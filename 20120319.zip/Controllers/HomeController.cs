﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Entity;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Security.Cryptography;
using QML.Library;
using QML.Library.Utilities;
using QML.Library.Helpers;
using QML.Library.Auth;
using QML.Library.Base.Controllers;
using QML.Library.Attributes;
using QML.Web.UI.Areas.DocumentAdmin.Helpers;
using QML.Web.UI.Areas.DocumentAdmin.Models;
using System.IO;
using System.Web.Helpers;
using QML.Web.UI.Areas.Core.Models;
using QML.Web.UI.Areas.Core.Controllers;
using QML.Web.UI.Models;

namespace QML.Web.UI.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        HanuELibraryEntities db = new HanuELibraryEntities();
        EssentialController ec = new EssentialController();

        public ActionResult Index(string id, string mod)
        {
            var x = Request.QueryString;
            if (!string.IsNullOrWhiteSpace(id))
                return View(id);
            if (!string.IsNullOrWhiteSpace(mod))
                return View(mod);

            IEnumerable<DocumentEssential> model = ec.getLatestBooks();
            ViewBag.BookLatest = model;
            return View();
        }

        public ActionResult CategoryView()
        {
            return View();
        }
        /*
        public ActionResult Test()
        {
            IEnumerable < DocumentEssential > t= null;
            string keyword = "quicksort";
            IEnumerable<DocWeightModel> view_model= ec.searchByContent(t,keyword);    
            return View(view_model);
        }
         */

        public ActionResult ViewByCategory(int id)
        {
            IEnumerable<DocumentEssential> view_model = ec.getFromCategory(id);
            ViewBag.CategoryName = db.DocumentCategories.FirstOrDefault(p => p.CategoryID == id).CategoryName;
            return View(view_model);
        }

        public ActionResult ViewByFormat(int id)
        {
            IEnumerable<DocumentEssential> view_model = ec.getFromFormat(id);
            ViewBag.Format = db.DocumentFormats.FirstOrDefault(p => p.DocumentFormatID == id).Name;
            return View(view_model);
        }

        public ActionResult ViewBook(int id)
        {
            if (ec.IsAuthenticated())
            {
                //Get document from id
                Document doc = db.Documents.FirstOrDefault(p => p.DocumentID == id);
                DocumentsFile file = db.DocumentsFiles.FirstOrDefault(p => p.DocumentID == id && p.IsDeleted == false && p.IsHasInfo == true && p.Status == "Hiển thị");
                DocumentEssential model = new DocumentEssential
                {
                    DocumentID = doc.DocumentID,
                    BookFee = file.BookFee.Value,
                    CategoryID = file.CategoryID.Value,
                    Status = file.Status,
                    Creator = doc.Creator,
                    Subject = doc.Subject,
                    Description = doc.Description,
                    Format = doc.Format,
                    FormatID = file.FormatID.Value,
                    Identifier = doc.Identifier,
                    IsDeleted = file.IsDeleted.Value,
                    IsHasInfo = file.IsHasInfo.Value,
                    Language = doc.Language,
                    Publisher = doc.Publisher,
                    Thumbnail = file.Thumbnail,
                    Title = doc.Title,
                    ViewCount = file.ViewCount.Value,
                    FileSource = file.FileSource,
                    FileName =  file.FileName
                };

                double fee = model.BookFee;
                string type = (fee > 0) ? "Fee" : "Free";

                //Minus the fee in user account, check if the action is completed
                bool x = ec.minusFee(model.DocumentID, fee);
                ec.DocumentStatisticUpdate(model);

                if (x == true)
                {
                    file.ViewCount = file.ViewCount + 1;
                    ViewHistory history = new ViewHistory
                    {
                        BookId = id,
                        UserId = ec.getUserId(),
                        ViewDate = DateTime.Now,
                        DocumentPublisher = model.Publisher,
                        DocumentTitle = model.Title,
                        CatId = model.CategoryID,
                        Type = type,
                        Fee = fee,
                        Year = DateTime.Now.Year,
                        Month = DateTime.Now.Month

                    };
                    db.ViewHistories.AddObject(history);
                    db.SaveChanges();
                    string doc_format = QML.Web.UI.Areas.DocumentAdmin.Helpers.DocumentsHelper.getFormatModel(file.FormatID.Value).FileFormat;
                    ViewBag.doc_format = doc_format;
                    if (doc_format == "pdf")
                    {
                        return View("ViewBook", model);
                    }

                    return View("ViewMedia", model);
                }
                else
                    return RedirectToAction("BalanceWarning");
            }
            else
                return RedirectToAction("AuthWarning", "Home");
        }
        public ActionResult ViewBookDetail(int id)
        {
            if (ec.IsAuthenticated())
            {
                //Get document from id
                Document doc = db.Documents.FirstOrDefault(p => p.DocumentID == id);
                DocumentsFile file = db.DocumentsFiles.FirstOrDefault(p => p.DocumentID == id && p.IsDeleted == false && p.IsHasInfo == true && p.Status == "Hiển thị");
                DocumentEssential model = new DocumentEssential
                {
                    DocumentID = doc.DocumentID,
                    BookFee = file.BookFee.Value,
                    CategoryID = file.CategoryID.Value,
                    Status = file.Status,
                    Creator = doc.Creator,
                    Subject = doc.Subject,
                    Description = doc.Description,
                    Format = doc.Format,
                    FormatID = file.FormatID.Value,
                    Identifier = doc.Identifier,
                    IsDeleted = file.IsDeleted.Value,
                    IsHasInfo = file.IsHasInfo.Value,
                    Language = doc.Language,
                    Publisher = doc.Publisher,
                    Thumbnail = file.Thumbnail,
                    Title = doc.Title,
                    ViewCount = file.ViewCount.Value,
                    FileSource = file.FileSource,
                    Date = doc.Date
                };
                double fee = model.BookFee;
                string type = (fee > 0) ? "Fee" : "Free";

                file.ViewCount = file.ViewCount + 1;
                ViewHistory history = new ViewHistory
                {
                    BookId = id,
                    UserId = ec.getUserId(),
                    ViewDate = DateTime.Now,
                    DocumentPublisher = model.Publisher,
                    DocumentTitle = model.Title,
                    CatId = model.CategoryID,
                    Type = type,
                    Fee = fee,
                    Year = DateTime.Now.Year,
                    Month = DateTime.Now.Month

                };
                db.ViewHistories.AddObject(history);
                db.SaveChanges();

                string doc_format = QML.Web.UI.Areas.DocumentAdmin.Helpers.DocumentsHelper.getFormatModel(file.FormatID.Value).FileFormat;
                ViewBag.doc_format = doc_format;
                return View("ViewBookDetail", model);


            }
            else
                return RedirectToAction("AuthWarning", "Home");
        }


        public ActionResult LogOff()
        {
            AccountController controller = new AccountController();
            controller.LogOff();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Logon()
        {
            return View();
        }

        //Cảnh báo khi chưa đăng nhập
        public ActionResult AuthWarning()
        {
            return View();
        }

        //Cảnh báo khi hết tiền trong tài khoản
        public ActionResult BalanceWarning()
        {
            return View();
        }

        /**
         * Search by document title
         **/
        public ActionResult SearchByTitle(FormCollection c)
        {
            string title = c.GetValue("search").AttemptedValue;
            IEnumerable<DocumentEssential> view_model = ec.SearchResult(title, 1, 0, 0, 0);
            SearchHistory history = new SearchHistory
            {
                UserId = ec.AuthManager.GetUser().UserId,
                Keyword = title,
                SearchDate = DateTime.Now
            };
            if (db.SearchHistories.FirstOrDefault(p => p.Keyword == title) == null)
            {
                db.SearchHistories.AddObject(history);
                db.SaveChanges();
            }
            IEnumerable<SearchHistory> histories = db.SearchHistories;
            foreach (var item in histories)
            {
                if (DateTime.Now.Date.AddDays(-20) == item.SearchDate.Date)
                {
                    db.SearchHistories.DeleteObject(item);
                }
            }
            db.SaveChanges();
            histories = db.SearchHistories.Take(5).OrderByDescending(p => p.SearchDate);
            ViewBag.History = histories;
            ViewBag.Search = title;
            return View(view_model.ToList());
        }

        //Search by title
        public ActionResult NormalSearch(string keyword)
        {
            IEnumerable<DocumentEssential> view_model = ec.SearchResult(keyword, 1, 0, 0, 1);
            IEnumerable<SearchHistory> history = db.SearchHistories;
            foreach (var item in history)
            {
                if (DateTime.Now.Date.AddDays(-20) == item.SearchDate.Date)
                {
                    db.SearchHistories.DeleteObject(item);
                }
            }
            db.SaveChanges();
            history = db.SearchHistories.Take(5).OrderByDescending(p => p.SearchDate);
            ViewBag.Keyword = keyword;
            ViewBag.History = history;
            return View(view_model);
        }

        //Advanced search
        public ActionResult Search()
        {
            IEnumerable<SearchHistory> history = db.SearchHistories;
            foreach (var item in history)
            {
                if (DateTime.Now.Date.AddDays(-20) == item.SearchDate.Date)
                {
                    db.SearchHistories.DeleteObject(item);
                }
            }
            db.SaveChanges();
            history = db.SearchHistories.Take(5).Distinct().OrderByDescending(p => p.SearchDate);
            ViewBag.History = history;
            return View();
        }

        public ActionResult SearchResult(FormCollection collection)
        {
            int DocumentType = 0;
            int DocumentCategory = 0;
            int Attribute = 0;
            int FeeType = 1;
            string Keyword = "";
            if (collection.GetValue("DocumentType").AttemptedValue != null)
                DocumentType = int.Parse(collection.GetValue("DocumentType").AttemptedValue);
            if (collection.GetValue("DocumentCategory").AttemptedValue != null)
                DocumentCategory = int.Parse(collection.GetValue("DocumentCategory").AttemptedValue);
            if (collection.GetValue("Attribute").AttemptedValue != null)
                Attribute = int.Parse(collection.GetValue("Attribute").AttemptedValue);
            if (collection.GetValue("Keyword").AttemptedValue != null)
                Keyword = collection.GetValue("Keyword").AttemptedValue;
            if (collection.GetValue("FeeType").AttemptedValue != null)
                FeeType = int.Parse(collection.GetValue("FeeType").AttemptedValue);
            IEnumerable<DocumentEssential> Result = ec.SearchResult(Keyword, Attribute, DocumentCategory, DocumentType, FeeType);
            IEnumerable<SearchHistory> history = db.SearchHistories;
            foreach (var item in history)
            {
                if (DateTime.Now.Date.AddDays(-20) == item.SearchDate.Date)
                {
                    db.SearchHistories.DeleteObject(item);
                }
            }
            db.SaveChanges();
            history = db.SearchHistories.Take(5).Distinct().OrderByDescending(p => p.SearchDate);
            ViewBag.Keyword = Keyword;
            ViewBag.History = history;
            ViewBag.FormAttributes = Keyword + ", " + Attribute + ", " + DocumentCategory + ", " + DocumentType + ", " + FeeType;

            return View(Result.ToList());
        }

        /**
         * History
         * */
        public ActionResult History(long id)
        {
            IEnumerable<ViewHistory> histories = db.ViewHistories.Where(p => p.UserId == id);
            foreach (var item in histories)
            {
                if (DateTime.Now.Date.AddDays(-20) >= item.ViewDate.Date)
                {
                    db.ViewHistories.DeleteObject(item);
                }
            }
            db.SaveChanges();
            histories = db.ViewHistories.Where(p => p.UserId == id);
            return View(histories.ToList());
        }

        /**
         * Unable to resolve! 
         */
        [HttpPost]
        public ActionResult Logon(LogOnModel model, string returnUrl)
        {
            model = new LogOnModel();
            returnUrl = "Home/Index";
            AccountController controller = new AccountController();
            controller.LogOn();
            return RedirectToAction("Index", "Home");
        }

        //Change password
        public ActionResult ChangePassword(long id)
        {
            auth_Users user = db.auth_Users.Include(p => p.auth_Roles).Include(p => p.Profile).FirstOrDefault(p => p.UserId == id);
            return View(user);
        }

        [HttpPost]
        public ActionResult ChangePassword(auth_Users user)
        {
            user.Password = EncodePassword(user.Password);
            db.auth_Users.Attach(user);
            db.Profiles.Attach(user.Profile);
            db.ObjectStateManager.ChangeObjectState(user, EntityState.Modified);
            db.ObjectStateManager.ChangeObjectState(user.Profile, EntityState.Modified);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        //Handling document order
        public ActionResult OrderDocument()
        {
            return View();
        }

        [HttpPost]
        public ActionResult OrderDocument(FormCollection c)
        {
            long id = ec.AuthManager.GetUser().UserId;
            string email="";
            if(db.auth_Users.FirstOrDefault(p => p.UserId == id).Profile != null){
               email =  db.auth_Users.FirstOrDefault(p => p.UserId == id).Profile.Email;
            }
            DocumentOrder order = new DocumentOrder
            {
                UserId = id,
                Status = false,
                OrderContent = c.GetValue("Content").AttemptedValue,
                CreatedDate = DateTime.Now,
                CreatedUser = id,
                LastModifiedDate = DateTime.Now,
                LastModifiedUser = id,
                UserEmail = email,
                DocumentName = c.GetValue("DocumentName").AttemptedValue,
                DocumentCategory = c.GetValue("DocumentCategory").AttemptedValue,
                DocumentCreator = c.GetValue("DocumentCreator").AttemptedValue,
                DocumentPublisher = c.GetValue("DocumentPublisher").AttemptedValue,
                DocumentType = c.GetValue("DocumentType").AttemptedValue,
                PublishedYear = c.GetValue("PublishedYear").AttemptedValue,
                Delivery = c.GetValue("Delivery").AttemptedValue

            };
            db.DocumentOrders.AddObject(order);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        private string EncodePassword(string input)
        {
            string output = "";
            output = Crypto.SHA1(input);
            return output.ToUpper();
        }
    }
}
